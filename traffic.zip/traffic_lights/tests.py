import unittest
from solution import traffic_lights as tl


road = """\
C...R............G......
.C..R............G......
..C.R............G......
...CR............G......
...CR............G......
....C............O......
....GC...........R......
....G.C..........R......
....G..C.........R......
....G...C........R......
....O....C.......R......""".split('\n')

res = tl(road[0], len(road)-1)

class TestSolution(unittest.TestCase):
    def test_output_type(self):
        self.assertTrue(isinstance(res, list))

        for item in res:
            self.assertTrue(isinstance(item, str))

    def test_res(self):
        self.assertEqual(len(res), len(road))
        self.assertEqual(res, road)

    def test_more(self):
        for i in range(len(road)):
            res = tl(road[0], len(road) - (i+1))
            self.assertEqual(res, road[i:])

if __name__ == '__main__': unittest.main()
