def traffic_lights(road, n):
    # Your code goes here
    return []
